const functions = require('@google-cloud/functions-framework');
const formData = require('form-data');
const Mailgun = require('mailgun.js');
const mailgun = new Mailgun(formData);
const mysql = require("mysql");

const mg = mailgun.client({username: 'api', key: process.env.MAILGUN_KEY});

const connection =  mysql.createConnection({
  host: process.env.DBURL,
  user: process.env.DBUSER,
  password: process.env.DBPASSWORD,
  database: process.env.DBNAME
});

connection.connect(function (err) {
  if (err) {
    console.error('Error in connecting to MySQL');
    return;
  }
  console.log('Connected to MySQL successfully');
});

functions.cloudEvent('helloPubSub', async (cloudEvent) => {
   try {
    const base64name = cloudEvent.data.message.data;
    const name = base64name
      ? Buffer.from(base64name, 'base64').toString()
      : 'World';
    const { userId, email, firstName, lastName } = JSON.parse(name);
    const activationLink = `https://webappbysamiksha.me/v1/user/verify?token=${userId}`;
    const msg = await mg.messages.create('mg.webappbysamiksha.me', {
      from: "<mailgun@mg.webappbysamiksha.me>",
      to: [email],
      subject: "Hello",
      text: `Hello ${firstName}, this email was sent from cloud function. Please click the following link to verify your email: ${activationLink}`,
      html: `<p>Hello ${firstName}, this email was sent from cloud function. Please click the following link to verify your email: <a href="${activationLink}">Verify Email</a></p>`
    });
    const queryString = `UPDATE Users SET verificationSentAt = NOW() WHERE id = '${userId}'`;
    connection.query(queryString, (err, results) => {
      if (err) {
        console.error('Error updating verificationSentAt:', err);
        return;
      }
      console.log('verificationSentAt updated successfully:', results);
    });

    console.log(msg); 
  } catch (error) {
    console.error(error); 
  }
});
